package com.uc.machiapp.model

data class UserData (
    val id: Int,
    val nickname: String,
    val email: String,
    val password: String
)