package com.uc.machiapp.model

data class LoginCredentials(val email: String, val password: String)