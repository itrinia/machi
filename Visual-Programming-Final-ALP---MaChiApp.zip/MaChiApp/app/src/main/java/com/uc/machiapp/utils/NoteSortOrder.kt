package com.uc.machiapp.utils

enum class NoteSortOrder {
    PRIORITY_ASC,
    PRIORITY_DESC,
    FILENAME_ASC,
    FILENAME_DESC,
    DATE_LAST_MOD_ASC,
    DATE_LAST_MOD_DESC
}