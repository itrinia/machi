package com.uc.machiapp.token

class TokenResponse {
    var token: String = ""
}