package com.uc.machiapp.model

data class User(
    val id: Int,
    val nickname: String,
    val email: String,
    val password: String
)