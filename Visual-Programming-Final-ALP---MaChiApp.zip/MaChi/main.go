package main

import "github.com/Jeshaiah04/MaChi/api"

func main() {
	api.Run()
}
